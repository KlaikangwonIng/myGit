package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        var tm = new TicketMachine(5.5,2);
        tm.receiveTicketsFromAdmin(3);
        tm.receiveTicketsFromAdmin(4);
        System.out.println(tm);
        tm.receiveCoinsFromCustomer(25);
        tm.receiveCoinsFromCustomer(12);
        System.out.println(tm);
        System.out.println(tm.sellTicketsToCustomer(5));
        System.out.println(tm);
        System.out.println(tm.giveAllCoinsToAdmin());
        System.out.println(tm);
       var a =10;
       // int a = 10
        var b = 2.2;
       //double b = 2.2
        var c = "hello";
        //String c = "hello"
    }

}