package org.example;

public class TicketMachine {
    private double ticketPrice = 0;
    private int numberOfTickets = 0;
    private int numberOfCoins = 0;
    private int customerCoins = 0;

    public TicketMachine(int numberOfTickets) {
        this.numberOfTickets = numberOfTickets;
    }

    public TicketMachine(double ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public TicketMachine(double ticketPrice, int numberOfTickets) {
        this.ticketPrice = ticketPrice;
        this.numberOfTickets = numberOfTickets;
    }

    public double getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(double ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public int getNumberOfTickets() {
        return numberOfTickets;
    }

    public int getNumberOfCoins() {
        return numberOfCoins;
    }

    public int getCustomerCoins() {
        return customerCoins;
    }

    //TODO:
    @Override
    public String toString() {
//        return String.format("TicketMachine{ticket price=%.2f, %d tickets, %d coins, customer %d coins}", ticketPrice, numberOfTickets, numberOfCoins, customerCoins);
                return "TicketMachine{ticketprice="+ ticketPrice + ','
                + numberOfTickets+ " tickets" + ','
                + numberOfCoins + " coins" + ','
                + "customer " + customerCoins + " coins";
    }


    public void receiveTicketsFromAdmin(int tickets) {
        numberOfTickets += tickets;
    }

    public int giveAllCoinsToAdmin() {
        int dummy = numberOfCoins;
        numberOfCoins = 0;
        return dummy;
    }

    public void receiveCoinsFromCustomer(int customerCoinsInput) {
        customerCoins += customerCoinsInput;
    }

    public int sellTicketsToCustomer(int needTickets) {
        int valueOfTickets = (int) Math.ceil(needTickets * ticketPrice);
        if (needTickets > numberOfTickets) {
            return -1;
        }
        if (valueOfTickets > customerCoins) {
            return -2;
        }

        numberOfTickets -= needTickets;

        numberOfCoins += valueOfTickets;
        //Changes
        customerCoins -= valueOfTickets;
        return returnCoinsToCustomer();
    }

    public int returnCoinsToCustomer() {
        int dummy = customerCoins;
        customerCoins = 0;
        return dummy;
    }

    public static void speak(){
        System.out.println("hello");
    }
}



