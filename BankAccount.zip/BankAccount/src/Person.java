public class Person {
    //Field
    private long idCard;
    private String firstName;
    private String lastName;

    //Constructor
    public Person(long idCard, String firstName, String lastName) {
        this.idCard = idCard;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    //Getter Setter
    public long getIdCard() {
        return idCard;
    }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    //toString
    @Override
    public String toString() {
        return "[" + "idCard=" + idCard + ", firstName='" + firstName + '\'' + ", lastName='" + lastName + '\'' + "]";

    }
}
