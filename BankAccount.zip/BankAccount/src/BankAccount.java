import javax.management.InvalidAttributeValueException;
import java.io.IOException;
import java.util.Arrays;

public class BankAccount {
    //Field
    private long account;
    private Person[] accountOwners;
    private double balance;
    private int accountOwnerCounting = 1;

    //Max account = 5
    public BankAccount(Person firstPersonForAccountOwner, int numberOfAccountOwners, double balance) {
        if (numberOfAccountOwners > 5) {
            //exceptions
        }
        this.accountOwners = new Person[numberOfAccountOwners];
        this.accountOwners[0] = firstPersonForAccountOwner;
        this.balance = balance;

        this.account = firstPersonForAccountOwner.getIdCard();

    }

    public boolean addAccountOwner(long idCard, String fName, String lName) {
        if (accountOwnerCounting == accountOwners.length) {
            return false;
        }

        Person dummy = new Person(idCard, fName, lName);

        accountOwners[accountOwnerCounting] = dummy;
        accountOwnerCounting += 1;

        return true;
    }

    public boolean withdraw(double amount) {
        if (amount > balance) {
            return false;
        }
        balance -= amount;
        return true;
    }

    public boolean deposit(double amount) {
        if (amount <= 0) {
            return false;
        }
        balance += amount;
        return true;
    }

    public boolean transfer(BankAccount targetAccount, double amount) {
        if (this.getBalance() > targetAccount.getBalance()) {
            targetAccount.deposit(amount);
            this.withdraw(amount);
            return true;
        }
        return false;

    }

    //getter
    public long getAccount() {
        return account;
    }

    public Person[] getAccountOwners() {
        return accountOwners;
    }

    public double getBalance() {
        return balance;
    }

    //    @Override
    public String toString() {

        return "BankAccount{" +
                "account=" + account +
                ", accountOwners=" + Arrays.toString(accountOwners) +
                ", balance=" + balance +
                "}";
    }

}
