// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Person kon1 = new Person(123456789,"Gun","git");
        Person kon2 = new Person(1234567810,"Dear","fu");
        Person kon3 = new Person(1234567811,"Ice","nay");
        BankAccount bank1 = new BankAccount(kon1,2,2000);
        BankAccount bank2 = new BankAccount(kon3, 2, 1000);

        bank2.addAccountOwner(1234567810,"Deer", "fu");
        System.out.println(bank2);

    }
}