public class MemberCard {
    private static final int Point2CASH100 = 800;
    private static final int BATH2POINTS = 25;
    private long memberId;
    private double totalPurchaseAmount;
    private int totalPoints;
    private int usagePoints;

    //Constructor
    public MemberCard(long idCard) {
        this.memberId = idCard;
    }

    //Method
    public void addPoints(double purchaseAmount) {
        totalPoints = (int) (purchaseAmount / BATH2POINTS);
    }
    public void buy(double purchaseAmount) {
        totalPurchaseAmount += purchaseAmount;
        addPoints(totalPurchaseAmount);

    }
    public int redeem() {
        if (totalPoints > 800) {
            totalPoints -= Point2CASH100;
            usagePoints += Point2CASH100;
            return 100;
        }
        return 0;
    }
    public int getNumberRedeem() {
        System.out.println("Times = " + usagePoints / Point2CASH100);
        return usagePoints / Point2CASH100;

    }

    //toString
    @Override
    public String toString() {
        return "MemberCard{" +
                "memberId=" + memberId +
                ", totalPurchaseAmount=" + totalPurchaseAmount +
                ", totalPoints=" + totalPoints +
                ", usagePoints=" + usagePoints +
                '}';
    }

    //getter
    public int getRemainingPoints() {
        return totalPoints;
    }

    public int getUsagePoints() {
        return usagePoints;
    }

    public int getTotalPoints() {
        return totalPoints;
    }

    public double getTotalPurchaseAmount() {
        return totalPurchaseAmount;
    }

    public long getMemberId() {
        return memberId;
    }


}
