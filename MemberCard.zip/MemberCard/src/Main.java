// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        MemberCard mc1 = new MemberCard(661305000000L);
        System.out.println(mc1);
        mc1.buy(100000);
        System.out.println(mc1);
        mc1.redeem();
        mc1.redeem();
        mc1.redeem();
        System.out.println(mc1);
        mc1.getNumberRedeem();
        System.out.println(mc1);
    }
}